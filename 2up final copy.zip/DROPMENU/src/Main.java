import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        flip CoinFlip = new flip();
        frame MyFrame = new frame();



    }
}