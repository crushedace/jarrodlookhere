public class flip {
    public flip() {
        if(Math.random()< 0.5){
            System.out.println("heads");
        }
        else{
            System.out.println("tails");
        }

    }
}
