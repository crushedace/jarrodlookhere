import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class flipTest {
    @RepeatedTest(15)
    void flipShouldBeRandom(){
        flip coinFlip = new flip();

    }

}