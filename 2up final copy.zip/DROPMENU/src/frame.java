import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;



public class frame extends JFrame implements ActionListener {


    JMenuBar menuBar;
    JMenu fileMenu;
    JMenuItem HelpItem;
    JMenuItem exitItem ;
    JMenu editMenu;
    JMenuItem bigText;
    JMenuItem smallText;
    JMenuItem defaultText;
    JMenu helpMenu;
    JMenuItem DarkMode;
    JMenuItem LightMode;
    JTextField textField;
    JButton submit;
    JButton heads;

    JButton tails;

    JLabel call;
    JLabel flipping;
    JLabel results;
    JLabel winLoss;



    frame(){


        //frame window
        GridBagConstraints gbc = new GridBagConstraints();
        this.setTitle("two up game");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new GridBagLayout());
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
        this.setSize(900,500);
        this.getContentPane().setBackground(Color.GRAY);

        // username entry

        //position of label
        textField = new JTextField();
        textField.setPreferredSize(new Dimension(230,40));
        textField.setFont(new Font("MV BOIL",Font.PLAIN,20));
        textField.setText("USERNAME");
        gbc.gridx = 0;
        gbc.gridy = 0;
        this.add(textField,gbc);

        submit = new JButton(" submit ");
        submit.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 0;
        //submit.setPreferredSize(new Dimension(85,40));
        submit.setFont(new Font("MV BOIL",Font.PLAIN,20));
        System.out.println(textField.getText());

        this.add(submit,gbc);

        // choice button HEADS x2
        heads = new JButton("HEADS/HEADS");
        heads.addActionListener(this);
        heads.setFont(new Font("MV BOIL",Font.PLAIN,20));
        gbc.gridx = 0;
        gbc.gridy = 2;
        //WriteFile.writeFileScores("chose heads " + textField.getText());

        this.add(heads,gbc);

        // choice button TAILS x2
        tails = new JButton("TAILS/TAILS");
        tails.addActionListener(this);
        tails.setFont(new Font("MV BOIL",Font.PLAIN,20));
        gbc.gridx = 1;
        gbc.gridy = 2;
        //WriteFile.writeFileScores("chose tails " + textField.getText());
        this.add(tails,gbc);

        //addActionListener((e) -> {
        //            System.out.println(textField.getText());
        //            String var10000 = textField.getText();
        //            WriteFile.writeFileScores("Players Name " + var10000 + label2.getText());
        //        });





        //game output for choice
        call = new JLabel();
        call.setText("");
        call.setFont(new Font("MV BOIL",Font.PLAIN,25));
        gbc.gridx = 0;
        gbc.gridy = 3;
        this.add(call,gbc);


        flipping = new JLabel();
        flipping.setText("");
        flipping.setFont(new Font("MV BOIL",Font.PLAIN,20));
        gbc.gridx = 0;
        gbc.gridy = 4;
        this.add(flipping,gbc);

        results = new JLabel();
        results.setText("");
        gbc.gridx = 0;
        gbc.gridy = 5;
        //results.setFont(new Font("MV BOIL",Font.PLAIN,20));
        this.add(results,gbc);

        winLoss = new JLabel();
        winLoss.setText("");
        gbc.gridx = 0;
        gbc.gridy = 6;
        //winLoss.setFont(new Font("MV BOIL",Font.PLAIN,20));
        this.add(winLoss,gbc);


        //menu bar

        menuBar= new JMenuBar();

        //menu bar fields
        fileMenu = new JMenu("File");
        editMenu = new JMenu("Edit");
        helpMenu = new JMenu("Mode");

        // menu items
        HelpItem = new JMenuItem("rules");
        exitItem = new JMenuItem("Exit");

        bigText = new JMenuItem("large"); //text gets big
        smallText = new JMenuItem("small"); //text gets small
        defaultText = new JMenuItem("default");//text becomes default

        LightMode = new JMenuItem("light Mode");
        DarkMode = new JMenuItem("dark mode ");


        HelpItem.addActionListener(this);
        exitItem.addActionListener(this);

        bigText.addActionListener(this);
        smallText.addActionListener(this);
        defaultText.addActionListener(this);

        LightMode.addActionListener(this);
        DarkMode.addActionListener(this);

        fileMenu.add(HelpItem);
        fileMenu.add(exitItem);

        editMenu.add(bigText);
        editMenu.add(defaultText);
        editMenu.add(smallText);

        helpMenu.add(LightMode);
        helpMenu.add(DarkMode);


        //menu bar on frame
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);

        this.setJMenuBar(menuBar);
        //this.pack();
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()== HelpItem){
            System.out.println(" BEEP BOOP saving ");
        }
        if(e.getSource()==exitItem){
            System.exit(0);
        }
        if(e.getSource()== DarkMode){
            this.setBackground(Color.BLACK);
            this.getContentPane().setBackground(Color.black);
        }
        if(e.getSource()== LightMode){
            this.setBackground(Color.WHITE);
            this.getContentPane().setBackground(Color.white);
        }
        if (e.getSource()==bigText){
            textField.setFont(new Font("MV BOIL",Font.PLAIN,30));
            submit.setFont(new Font("MV BOIL",Font.PLAIN,30));
            heads.setFont(new Font("MV BOIL",Font.PLAIN,30));
            tails.setFont(new Font("MV BOIL",Font.PLAIN,30));
            call.setFont(new Font("MV BOIL",Font.PLAIN,30));
            flipping.setFont(new Font("MV BOIL",Font.PLAIN,30));
            results.setFont(new Font("MV BOIL",Font.PLAIN,30));
            winLoss.setFont(new Font("MV BOIL",Font.PLAIN,30));

        }
        if (e.getSource()==defaultText){
            textField.setFont(new Font("MV BOIL",Font.PLAIN,20));
            submit.setFont(new Font("MV BOIL",Font.PLAIN,20));
            heads.setFont(new Font("MV BOIL",Font.PLAIN,20));
            tails.setFont(new Font("MV BOIL",Font.PLAIN,20));
            call.setFont(new Font("MV BOIL",Font.PLAIN,20));
            flipping.setFont(new Font("MV BOIL",Font.PLAIN,20));
            results.setFont(new Font("MV BOIL",Font.PLAIN,20));
            winLoss.setFont(new Font("MV BOIL",Font.PLAIN,20));
        }
        if (e.getSource()==smallText){
            textField.setFont(new Font("MV BOIL",Font.PLAIN,10));
            submit.setFont(new Font("MV BOIL",Font.PLAIN,10));
            heads.setFont(new Font("MV BOIL",Font.PLAIN,10));
            tails.setFont(new Font("MV BOIL",Font.PLAIN,10));
            call.setFont(new Font("MV BOIL",Font.PLAIN,10));
            flipping.setFont(new Font("MV BOIL",Font.PLAIN,10));
            results.setFont(new Font("MV BOIL",Font.PLAIN,10));
            winLoss.setFont(new Font("MV BOIL",Font.PLAIN,10));
        }
        if(e.getSource()==submit){
            System.out.println(textField.getText());
            WriteFile.writeFileScores("Players Name " + textField.getText() + winLoss.getText());
        }
        if(e.getSource()==heads){
            call.setText(" you chose double heads");
            flipping.setText(" flipping coins");
            {if(Math.random()< 0.5){results.setText(" double Heads");
                winLoss.setText(" you win");
                WriteFile.writeFileScores(winLoss.getText());}
                else{results.setText("double Tails");
                winLoss.setText(" you lose");}
                WriteFile.writeFileScores(winLoss.getText());
            }
        }
        if (e.getSource()==tails) {
            call.setText("you chose double tails");
            flipping.setText("flipping coins");
            {if(Math.random()< 0.5){results.setText("tails");
            winLoss.setText(" you win");}
            else{results.setText(" Heads");
            winLoss.setText(" you lose");}
            }
        }
    }
}

