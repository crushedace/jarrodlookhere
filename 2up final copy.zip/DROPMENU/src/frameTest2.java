import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class frameTest2 {

    @Test
    void frameShouldExist() {
        frame MyFrame = new frame();
    }
}